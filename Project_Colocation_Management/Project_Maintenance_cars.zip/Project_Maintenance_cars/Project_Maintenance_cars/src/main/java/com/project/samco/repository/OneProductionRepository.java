package com.project.samco.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.samco.model.OneProduction;
import com.project.samco.model.Poste;
import com.project.samco.model.Travallier;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Repository
public interface OneProductionRepository extends JpaRepository<OneProduction, Long> {
	 //Poste findBynumeroposte(Long numeroposte);
	OneProduction findByTravallierAndDate(Travallier travallier, Date date);
    OneProduction findByPosteAndDate(Poste poste, Date date);
    List<OneProduction> findAllByDate(Date date);
    boolean existsByTravallierAndDate(Travallier travallier, Date date);
}
