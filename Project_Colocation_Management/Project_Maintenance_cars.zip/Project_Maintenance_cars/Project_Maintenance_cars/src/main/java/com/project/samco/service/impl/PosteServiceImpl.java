package com.project.samco.service.impl;


import com.project.samco.model.Poste;
import com.project.samco.repository.PosteRepository;


import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

@Service
public class PosteServiceImpl {
	
	
	
	

    private final PosteRepository posteRepository;
   


    public PosteServiceImpl(PosteRepository posteRepository) {
        this.posteRepository = posteRepository;
       
    }

    
    public Poste savePoste(Poste poste) {
        return posteRepository.save(poste);
    }
    
    

    public Poste incrementProduction(Long id, int numbre) {
        try {
            Poste poste = posteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Poste not found with id: " + id));
            poste.setProductiontotal(poste.getProductiontotal() + numbre);
            poste.setProductivitetotal( (((float) poste.getProductiontotal() / (float) poste.getObjectif() )* 100));
            return posteRepository.save(poste);
        } catch (EntityNotFoundException e) {
           
            return null;
           
        }}

    
    
    public Poste incrementRetouche(Long id, int numbre) {
        try {
            Poste poste = posteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Poste not found with id: " + id));
            poste.setRetouchetotal(poste.getRetouchetotal() + numbre);
            return posteRepository.save(poste);
        } catch (EntityNotFoundException e) {
            return null;
           
        }}
    
    
    
    
    
    
    

  
   /*public Poste changeTravallierPoste(Long travallierId, Long posteId) {
        Travallier travallier = travallierServiceImpl.getTravallierById(travallierId);
        Poste poste = getPosteById(posteId);
        
        
        if (travallier != null && poste != null) {
        	
        	Travallier lasttravaller = travallierServiceImpl.getTravallierByposte(poste);
            if ( lasttravaller != null) {
            	
            	lasttravaller.setDefaultposte(poste);
            	
            }
            
            Poste lastpost = getPosteByTravaller(travallierId);
            if ( lastpost != null) {
            	 lastpost.setTravallier(null);
            	
            	
            }
           
            
             poste.setTravallier(travallier);
            return savePoste(poste);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Travallier or Poste not found");
        }
    }*/

   
    public Poste getPosteById(Long id) {
        Optional<Poste> optionalPoste = posteRepository.findById(id);
        return optionalPoste.orElse(null);
    }

  /*  public Poste getPosteByTravaller(long travallierId) {
    	Travallier travallier = travallierServiceImpl.getTravallierById(travallierId);
    	if (travallier != null) {
    		return   posteRepository.findByTravallier(travallier);
         }
		return null;
    }*/
  
    public Poste getPosteBynumeroposte(long numeroposte) {
        Optional<Poste> optionalPoste = Optional.ofNullable(posteRepository.findBynumeroposte(numeroposte));
        return optionalPoste.orElse(null);
    }

   
    public List<Poste> getAllPostes() {
        return posteRepository.findAll();
    }

   
    public void deletPoste(Long id) {
        posteRepository.deleteById(id);
    }
}
