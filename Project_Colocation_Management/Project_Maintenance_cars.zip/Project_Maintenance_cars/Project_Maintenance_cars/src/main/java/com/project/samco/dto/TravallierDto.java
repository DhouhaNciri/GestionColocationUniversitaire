package com.project.samco.dto;





import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TravallierDto {
   
    
    private   String fingerprint;
    @NonNull
    private Long cin;
    @NonNull
    private String name;
    @NonNull
    private  String prenome;
  
    private Long defaultposte;
   

    
	
  
}
