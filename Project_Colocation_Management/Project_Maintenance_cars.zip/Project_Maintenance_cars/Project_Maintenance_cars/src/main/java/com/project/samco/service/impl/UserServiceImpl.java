package com.project.samco.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.util.StringUtils;

import com.project.samco.model.Role;
import com.project.samco.model.User;
import com.project.samco.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl {

    private final UserRepository userRepository;
    
    
    
    
    // This method loads user details by username (in this case, email)
    public UserDetailsService userDetailsService() {
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) {
                if (StringUtils.isEmpty(username)) {
                    throw new IllegalArgumentException("Username cannot be null or empty");
                }

                Optional<User> userOptional = userRepository.findByEmail(username);
                if (userOptional.isPresent()) {
                    return userOptional.get();
                } else {
                    throw new UsernameNotFoundException("User not found with username: " + username);
                }
            }
        };
    }

    
    @Transactional
    public User save(User newUser) {
        if (newUser.getId() == null) {
            newUser.setCreatedAt(LocalDateTime.now());
        }

        newUser.setUpdatedAt(LocalDateTime.now());
    
        return userRepository.save(newUser);
    }

 
    @Transactional
    public void delete(Long userId) {
        userRepository.deleteById(userId);
    }
    
    
   
    public Optional<User> getUserbyid(Long userId) {
        
		return userRepository.findById(userId);
    }

    
    @Transactional
    public User update(User updatedUser) {
        if (userRepository.existsById(updatedUser.getId())) {
            updatedUser.setUpdatedAt(LocalDateTime.now());
         
            return userRepository.save(updatedUser);
        } else {
            throw new IllegalArgumentException("User with provided ID does not exist");
        }
    }

 
    public User getByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found for email: " + email));
    }
    
    
    public  List<String> findTokenFcmByRole(Role role){
		return userRepository.findTokenFcmByRole(role);
 
    	
    }
    
    
    public List<User> allusers() {
        return userRepository.findAll();
    }
    
    
    public List<User> findAdmins() {
        return userRepository.findByRole(Role.ROLE_ADMIN);
    }
    
    public List<User> findTechnicians() {
        return userRepository.findByRole(Role.ROLE_TECHNICIEN);
    }
    
    public List<User> findQulite() {
        return userRepository.findByRole(Role.ROLE_CONTROLE_QULITE);
    }
    
    public List<User> findProd() {
        return userRepository.findByRole(Role.ROLE_CONTROLE_PROD);
    }
    
    
    
    
    
    
    

    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
 
// @Transactional
 public User updateTokenFCM(String email, String newTokenFCM) {
     User user = getByEmail(email);
     user.setTokenfcm(newTokenFCM);
     user.setUpdatedAt(LocalDateTime.now()); 
     return userRepository.save(user);
 }

    
    
    
    
    
    
    
    
  
}
