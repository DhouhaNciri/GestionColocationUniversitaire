package com.project.samco.mapper;



import org.mapstruct.Mapper;


@Mapper
public interface PosteMapper {

    
}
