package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class JourProduction implements Serializable {

    private static final long serialVersionUID = 1L;

	@Id
	@JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Temporal(TemporalType.DATE)
    private Date date;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "jour_production_id") 
    private List<OneProduction> presence;

    @JsonIgnore
    @OneToMany(mappedBy = "oneProduction", cascade = CascadeType.ALL)
    private List<JourDefaut> jourDefauts;
    
    
    
    @PrePersist
    protected void onCreate() {
        if (this.date == null) {
            this.date = new Date();
        }
    }
}
