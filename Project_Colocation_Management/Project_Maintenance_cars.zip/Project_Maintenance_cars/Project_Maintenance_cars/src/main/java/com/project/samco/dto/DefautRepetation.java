package com.project.samco.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;







@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class DefautRepetation {
	
	
	private  long id;
	
	

	private  String name;

	private  int repetition;
	
	private  float percentage;
	
}
