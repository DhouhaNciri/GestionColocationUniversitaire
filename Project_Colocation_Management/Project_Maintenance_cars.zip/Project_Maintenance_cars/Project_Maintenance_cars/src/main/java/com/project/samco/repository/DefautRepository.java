package com.project.samco.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.project.samco.model.Defaut;
@Repository
public interface DefautRepository extends JpaRepository<Defaut, Long> {
   
}
