package com.project.samco.service;

import com.project.samco.dto.JwtAuthenticationResponse;
import com.project.samco.dto.SignInRequest;
import com.project.samco.dto.SignUpRequest;

public interface AuthenticationService {
    JwtAuthenticationResponse signup(SignUpRequest request);
    JwtAuthenticationResponse signin(SignInRequest request);
}
