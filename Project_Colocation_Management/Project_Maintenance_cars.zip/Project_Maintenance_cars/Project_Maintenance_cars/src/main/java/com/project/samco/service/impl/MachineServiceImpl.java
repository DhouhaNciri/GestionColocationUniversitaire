package com.project.samco.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.samco.model.Machine;
import com.project.samco.repository.MachineRepository;

@Service
public class MachineServiceImpl {

    @Autowired
    private MachineRepository machineRepository;

    // Méthode pour enregistrer une machine
    public Machine saveMachine(Machine machine) {
        return machineRepository.save(machine);
    }

    // Méthode pour récupérer toutes les machines
    public List<Machine> getAllMachines() {
        return machineRepository.findAll();
    }

    // Méthode pour récupérer une machine par son identifiant
    public Optional<Machine> getMachineById(Long id) {
        return machineRepository.findById(id);
    }

    // Méthode pour mettre à jour une machine
    public Machine updateMachine(Long id, Machine updatedMachine) {
        if (machineRepository.existsById(id)) {
            updatedMachine.setId(id);
            return machineRepository.save(updatedMachine);
        } else {
            return null; // Gérer le cas où la machine n'existe pas
        }
    }

    // Méthode pour supprimer une machine
    public void deleteMachine(Long id) {
        machineRepository.deleteById(id);
    }
}
