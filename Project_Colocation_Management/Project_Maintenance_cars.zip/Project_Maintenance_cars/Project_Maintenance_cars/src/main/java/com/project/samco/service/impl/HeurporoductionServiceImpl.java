package com.project.samco.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.samco.model.Heureproduction;
import com.project.samco.model.Machine;
import com.project.samco.repository.HeurproductionRepository;
import com.project.samco.repository.MachineRepository;

@Service
public class HeurporoductionServiceImpl {

    @Autowired
    private HeurproductionRepository repository;

    
    public Heureproduction saveMachine(Heureproduction repositor) {
        return repository.save(repositor);
    }

    // Méthode pour récupérer toutes les machines
    public List<Heureproduction> getAllMachines() {
        return repository.findAll();
    }

   
    public Optional<Heureproduction> getMachineById(Long id) {
        return repository.findById(id);
    }

   
    public Heureproduction updateMachine(Long id, Heureproduction updated) {
        if (repository.existsById(id)) {
            updated.setId(id);
            return repository.save(updated);
        } else {
            return null; // Gérer le cas où la machine n'existe pas
        }
    }

    // Méthode pour supprimer une machine
    public void deleteMachine(Long id) {
    	repository.deleteById(id);
    }
}
