package com.project.samco.model;

public enum Role {
  ROLE_ADMIN,
  ROLE_USER,
  ROLE_TECHNICIEN,
  ROLE_CONTROLE_QULITE,
  ROLE_CONTROLE_PROD
}
