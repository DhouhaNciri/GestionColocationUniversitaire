package com.project.samco.controller;

import com.project.samco.dto.PosteDto;
import com.project.samco.model.Poste;
import com.project.samco.service.impl.PosteServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postes")
public class PosteController {
	 @Autowired
    private  PosteServiceImpl posteServiceImpl;


    @PostMapping
    public ResponseEntity<?> createPoste(@RequestBody PosteDto posteDto) {
    	 if (!isAdmin()) {
             return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
         }
        try {
            
            if (posteServiceImpl.getPosteBynumeroposte(posteDto.getNumeroposte()) != null) {
                return new ResponseEntity<>("A poste with the same numeroposte already exists", HttpStatus.CONFLICT);
            }
            
            Poste createdPoste = posteServiceImpl.savePoste(new Poste(posteDto.getNumeroposte(), posteDto.getOperation(),posteDto.getObjectif()));
            
 
            return new ResponseEntity<>("[]", HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to create poste: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    


    @GetMapping("/{id}")
    public ResponseEntity<?> getPosteById(@PathVariable Long id) {
        try {
            Poste poste = posteServiceImpl.getPosteById(id);
            if (poste != null) {
                return new ResponseEntity<>(poste, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Poste not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to retrieve poste: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
   /* @GetMapping("/travallier/{id}")
    public ResponseEntity<?> getPosteByTravaller(@PathVariable Long id) {
        try {
            Poste poste = posteServiceImpl.getPosteByTravaller(id);
            if (poste != null) {
                return new ResponseEntity<>(poste, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Poste not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to retrieve poste: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
    
    
    
    

    @GetMapping
    public ResponseEntity<?> getAllPostes() {
        try {
            List<Poste> postes = posteServiceImpl.getAllPostes();
            return new ResponseEntity<>(postes, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to retrieve postes: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePoste(@PathVariable Long id) {
    	 if (!isAdmin()) {
             return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
         }
        try {
            posteServiceImpl.deletPoste(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete poste: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
  /*  @PutMapping("/incrementprod/{id}")
    public ResponseEntity<Poste> incrementProductivite(@PathVariable Long id, @RequestParam int augmentation) {
        if (augmentation < 1) {
            return ResponseEntity.badRequest().build();
        }

        Poste incrementeproductivite = posteServiceImpl.incrementProduction(id, augmentation);
        if (incrementeproductivite != null) {
            return ResponseEntity.ok(incrementeproductivite);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    
    @PutMapping("/incrementret/{id}")
    public ResponseEntity<Poste> incrementRetouche(@PathVariable Long id, @RequestParam int augmentation) {
        if (augmentation < 1) {
            return ResponseEntity.badRequest().build();
        }

        Poste incrementRetouche = posteServiceImpl.incrementRetouche(id, augmentation);
        if (incrementRetouche != null) {
            return ResponseEntity.ok(incrementRetouche);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    
  /*  @PutMapping("/change/{posteid}")
    public ResponseEntity<Poste> changeTravallierPoste(@PathVariable Long posteid, @RequestParam Long id) {
        if (posteid < 1) {
            return ResponseEntity.badRequest().build();
        }

        Poste changeposte = posteServiceImpl.changeTravallierPoste(id, posteid);
        if (changeposte != null) {
            return ResponseEntity.ok(changeposte);
        } else {
        	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }
    */
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                             .anyMatch(role -> role.getAuthority().equals("ROLE_ADMIN"));
    }
}
