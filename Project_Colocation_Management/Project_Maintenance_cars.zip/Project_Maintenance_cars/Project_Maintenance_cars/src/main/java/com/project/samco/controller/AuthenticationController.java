
package com.project.samco.controller;

import com.project.samco.dto.JwtAuthenticationResponse;
import com.project.samco.dto.SignInRequest;
import com.project.samco.dto.SignUpRequest;
import com.project.samco.dto.UserDto;
import com.project.samco.model.User;
import com.project.samco.service.impl.AuthenticationServiceImpl;
import com.project.samco.service.impl.UserServiceImpl;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthenticationServiceImpl authenticationService;
    private final UserServiceImpl userServiceImpl;

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody @Validated SignUpRequest request) {
    	
    	if (!userServiceImpl.existsByEmail(request.getEmail())) {
			
		
        try {
            JwtAuthenticationResponse response = authenticationService.signup(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred during signup.");
        }}else {
    	 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User with email already exists.");
    }}

    @PostMapping("/signin")
    public ResponseEntity<?> signin(@RequestBody @Validated SignInRequest request) {
        try {
            JwtAuthenticationResponse response = authenticationService.signin(request);
            return ResponseEntity.ok(response);
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found. Please check your email or sign up.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Invalid email or password.");
        }
    }
    @GetMapping("/me")
    private UserDto me() {
    	
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("Authentication failed or user not authenticated");
        }
        
       User us= (User) authentication.getPrincipal();
       UserDto dto=new UserDto(us.getId(), us.getFirstName()+" "+ us.getLastName(), us.getEmail());
       return dto;
    }
    
}
