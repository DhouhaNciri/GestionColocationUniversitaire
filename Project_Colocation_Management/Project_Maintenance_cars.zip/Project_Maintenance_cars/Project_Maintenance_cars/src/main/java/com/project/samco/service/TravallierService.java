package com.project.samco.service;


import com.project.samco.model.Travallier;

import java.util.List;

public interface TravallierService {
    Travallier saveTravallier(Travallier travallier);

    Travallier updateTravallier(Long id, Travallier updatedTravallier);

   // Travallier changePosteTravallier(Long travallierId, Long posteId);

    List<Travallier> getAllTravalliers();

    Travallier getTravallierById(Long travallierId);

  //  Travallier getTravallierByposte(Poste poste);

    Travallier getTravallierByFingerprint(String fingerprint);

    Travallier getTravallierByCin(Long cin);

    void deleteTravallier(Long id);
}
