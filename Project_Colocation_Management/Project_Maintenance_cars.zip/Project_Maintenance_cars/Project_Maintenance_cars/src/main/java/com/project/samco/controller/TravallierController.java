package com.project.samco.controller;


import com.project.samco.dto.AllTravallierDto;
import com.project.samco.dto.TravallierDto;
import com.project.samco.model.Travallier;
import com.project.samco.service.impl.PosteServiceImpl;
import com.project.samco.service.impl.TravallierServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/travalliers")
public class TravallierController {
@Autowired
   private  TravallierServiceImpl travallierServiceImpl;
    @Autowired
    private PosteServiceImpl posteServiceImpl;
    
    
    
    

    @PostMapping
    public ResponseEntity<?> saveTravallier(@RequestBody TravallierDto travDto) {
    	 if (!isAdmin()) {
             return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
         }
        try {
        	if (travallierServiceImpl.getTravallierByCin(travDto.getCin()) != null) {
                return new ResponseEntity<>("A Travallier with the same cin already exists", HttpStatus.CONFLICT);
            }else {
            	if (travallierServiceImpl.getTravallierByFingerprint(travDto.getFingerprint()) != null) {
                    return new ResponseEntity<>("A Travallier with the same Fingerprint already exists", HttpStatus.CONFLICT);
                }else {
            	
            Travallier savedTravallier = travallierServiceImpl.saveTravallier(new Travallier(travDto.getFingerprint(), travDto.getCin(), travDto.getName(), travDto.getPrenome(), posteServiceImpl.getPosteById(travDto.getDefaultposte())));
            return new ResponseEntity<>("[]", HttpStatus.CREATED);}}
        } catch (DuplicateKeyException e) {
            return new ResponseEntity<>("Fingerprint or CIN already exists", HttpStatus.CONFLICT);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to save Travallier: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    
    
    
    @PutMapping("/{travallierId}/change-default-poste/{posteId}")
    public Travallier changeDefaultPosteTravallier(@PathVariable Long travallierId, @PathVariable Long posteId) {
        try {
        return	travallierServiceImpl.changedefaultPosteTravallier(travallierId, posteId);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while changing Travallier's poste", e);
        }
		
    }
    
    

    @GetMapping
    public ResponseEntity<List<AllTravallierDto>> getAllTravalliers() {
        List<Travallier> allTravalliers = travallierServiceImpl.getAllTravalliers();
        List<AllTravallierDto> allTravallierDtos =new ArrayList<AllTravallierDto>();
        for (Travallier travallier : allTravalliers) {
        	allTravallierDtos.add(new AllTravallierDto(travallier.getId(),travallier.getName()+" "+travallier.getPrenome(), travallier.getDefaultposte().getId()));
			
		}
        
        return new ResponseEntity<>(allTravallierDtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTravallierById(@PathVariable Long id) {
        try {
            Travallier travallier = travallierServiceImpl.getTravallierById(id);
            if (travallier != null) {
                return new ResponseEntity<>(travallier, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Travallier not found", HttpStatus.NOT_FOUND);
            }
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>("Invalid ID provided: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to get Travallier: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTravallier(@PathVariable Long id) {
    	 if (!isAdmin()) {
             return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
         }
        try {
            travallierServiceImpl.deleteTravallier(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>("Invalid ID provided: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete Travallier: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                             .anyMatch(role -> role.getAuthority().equals("ROLE_ADMIN"));
    }
    
    
   
}
