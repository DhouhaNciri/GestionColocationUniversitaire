package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Poste implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @JsonIgnore
    private long numeroposte;

    @NonNull
    private String operation;

    private int objectif = 27;
    private int productiontotal=0;
    private float productivitetotal=0;
    private float retouchetotal=0;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonIgnore
    private Date date;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "poste")
    private List<Machine> machines = new ArrayList<>();

    public Poste(Long numeroposte, @NonNull String operation) {
        super();
        this.numeroposte = numeroposte;
        this.operation = operation;
        this.date = new Date();
    }

    public Poste(@NonNull Long numeroposte, @NonNull String operation, int objectif) {
        super();
        this.numeroposte = numeroposte;
        this.operation = operation;
        this.objectif = objectif;
        this.date = new Date();
    }
}
