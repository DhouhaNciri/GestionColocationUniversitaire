package com.project.samco.model;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class Heureproduction   {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  Long id;
	
	@ManyToOne
    @JsonIgnore
    @JoinColumn(name = "on_production_id")
    private OneProduction oneProduction;
	 
	 private Long poste;

	   

	    private int production;
	    private int Retouche;
	    private float productivite;
	    

	    @CreationTimestamp
	    private LocalDateTime heures; 
	    
	    
	    private String commentaire;

	    // Constructor to initialize the heures attribute with the current hour
	    public Heureproduction( long poste, int production, int Retouche, float productivite) {
	      //  this.travallier = travallier;
	       this.poste = poste;
	        this.production = production;
	        this.Retouche = Retouche;
	        this.productivite = productivite;
	        this.heures = LocalDateTime.now();
	    }

	    // Getter method to extract the hour part from heures as an int
	    public int getHeuresAsInt() {
	        return heures.getHour();
	    }
	

	    public int getMinutesAsInt() {
	        return heures.getMinute();
	    }

	
	
}
