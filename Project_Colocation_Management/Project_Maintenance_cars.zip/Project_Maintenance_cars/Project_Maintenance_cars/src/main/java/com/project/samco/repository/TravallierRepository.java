package com.project.samco.repository;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.project.samco.model.Travallier;
@Repository
public interface TravallierRepository extends JpaRepository<Travallier, Long> {
	 Travallier findByFingerprint(String fingerprint);
	 Travallier findBycin(Long cin);
	 
	// Travallier findByjourposte(Poste jourposte);
	void deleteById(Long id);
	boolean existsByFingerprint(String fingerprint);
	boolean existsById(Long id);
}
