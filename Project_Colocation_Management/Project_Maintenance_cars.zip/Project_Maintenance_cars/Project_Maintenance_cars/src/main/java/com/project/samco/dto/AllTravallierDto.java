package com.project.samco.dto;





import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AllTravallierDto {
   
    
  private long id;
    @NonNull
    private String name;
   
    private Long defaultposte;
   

    
	
  
}
