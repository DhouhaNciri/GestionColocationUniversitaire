package com.project.samco.config;




import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;




@Component
public class AppStartUp implements CommandLineRunner{
	
	
	

	@Override
	public void run(String... args) throws Exception {
		
	/*	if (roleService.getAllRoles().isEmpty()) {		
		
			roleService.addRole("ADMIN");
			roleService.addRole("USER");
		}*/
	}

}
