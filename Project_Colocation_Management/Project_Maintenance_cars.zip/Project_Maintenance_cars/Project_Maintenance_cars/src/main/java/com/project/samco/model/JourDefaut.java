package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class JourDefaut {

    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    private Defaut defaut;
    
    @JsonIgnore
    @Temporal(TemporalType.DATE)
    private Date date;

    public JourDefaut(Defaut defaut, OneProduction oneProduction, int repetition) {
		super();
		this.defaut = defaut;
		this.oneProduction = oneProduction;
		this.repetitionjour = repetition;
	}
    @JsonIgnore
	@ManyToOne
    private OneProduction oneProduction;

    private int repetitionjour;
    private float percentagejour;
    
    @PrePersist
    protected void onCreate() {
        if (this.date == null) {
            this.date = new Date();
        }
    }

}
