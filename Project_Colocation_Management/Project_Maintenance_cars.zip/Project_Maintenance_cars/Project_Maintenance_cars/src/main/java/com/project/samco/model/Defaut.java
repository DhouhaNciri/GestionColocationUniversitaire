package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;









@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class Defaut   {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  Long id;
	
	@NonNull
	private  String name;
	
	@NonNull
	@ElementCollection
	@OneToMany(cascade = CascadeType.ALL ,fetch = FetchType.EAGER)
	private  List<Files> images;
	
	public Defaut(@NonNull String name, @NonNull List<Files> images) {
		super();
		this.name = name;
		this.images = images;
	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	

	public int getRepetition() {
		return repetitiontotal;
	}

	public void setRepetition(int repetition) {
		this.repetitiontotal = repetition;
	}

	public float getPercentage() {
		return percentagetotal;
	}

	public void setPercentage(float percentage) {
		this.percentagetotal = percentage;
	}

	public static int getTotalDefaut() {
		return TotalDefaut;
	}

	public static void setTotalDefaut(int totalDefaut) {
		TotalDefaut = totalDefaut;
	}



	private  int repetitiontotal;
	
	private  float percentagetotal;
	
	private static int TotalDefaut;
	
}
