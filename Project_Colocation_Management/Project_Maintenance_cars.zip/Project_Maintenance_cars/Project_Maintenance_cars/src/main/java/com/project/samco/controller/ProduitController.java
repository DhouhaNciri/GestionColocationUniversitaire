package com.project.samco.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.multipart.MultipartFile;


import com.project.samco.model.Produit;
import com.project.samco.service.impl.FilesServiceImpl;
import com.project.samco.service.impl.ProduitServiceImpl;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/produits")
public class ProduitController {

    @Autowired
    private ProduitServiceImpl produitServiceImpl;
    @Autowired
    private FilesServiceImpl filesServiceImpl;

    @PostMapping
    public ResponseEntity<Produit> addProduit(@RequestParam String name, @RequestParam String description,@RequestParam List<MultipartFile> files) throws Exception {
        if (!isAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Produit newProduit = produitServiceImpl.addProduit(name,description, filesServiceImpl.storeFiles(files));
        return ResponseEntity.status(HttpStatus.CREATED).body(newProduit);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduitById(@PathVariable Long id) {
      
        if (!isAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        if (produitServiceImpl.getProduitById(id).isPresent()) {
            try {
                produitServiceImpl.deleteProduitById(id);
                return ResponseEntity.ok().body("Produit with ID: " + id + " deleted successfully.");
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                     .body("Failed to delete Produit with ID: " + id);
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

  
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                             .anyMatch(role -> role.getAuthority().equals("ROLE_ADMIN"));
    }

    @GetMapping
    public ResponseEntity<List<Produit>> getAllDefauts() {
        List<Produit> produits = produitServiceImpl.getAllProduit();
        return ResponseEntity.ok(produits);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produit> getProduitById(@PathVariable Long id) {
        Optional<Produit> optional = produitServiceImpl.getProduitById(id);
        return optional.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produit> updateDefaut(@PathVariable Long id, @RequestBody Produit produit) {
        Produit updatedProduit = produitServiceImpl.updateProduit(id, produit.getName(),produit.getMedia(), produit.getDescription(),produit.getDefauts());
        if (updatedProduit != null) {
            return ResponseEntity.ok(updatedProduit);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

  
}
