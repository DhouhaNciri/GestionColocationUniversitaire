package com.project.samco.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.project.samco.model.Defaut;
import com.project.samco.model.Files;
import com.project.samco.model.Produit;
import com.project.samco.repository.ProduitRepository;
import com.project.samco.service.ProduitService;

@Service
public  class ProduitServiceImpl implements ProduitService {
	
	 @Autowired
	    ProduitRepository produitRepository;

	    @Autowired
	    FilesServiceImpl filesServiceImpl;

	    
	    public Produit addProduit(String name,String description, List<Files> list) throws Exception {
	        return produitRepository.save(new Produit(name, list, description));
	    }

	 
	    public List<Produit> getAllProduit() {
	        return produitRepository.findAll();
	    }

	
	    public Optional<Produit> getProduitById(Long id) {
	        return produitRepository.findById(id);
	    }

	 
	    public Produit updateProduit(Long id, String name, List<Files> images, String description, List<Defaut> defauts) {
	        Optional<Produit> optional = produitRepository.findById(id);
	        if (optional.isPresent()) {
	            Produit produit = optional.get();
	            produit.setName(name);
	            produit.setMedia(images);
	            produit.setDescription(description);
	            produit.setDefauts(defauts);
	            return produitRepository.save(produit);
	        } else {
	            return null;
	        }
	    }

	  
	   

	  
	    public void deleteProduitById(Long id) throws Exception {
	        List<Files> media = getProduitById(id).orElseThrow().getMedia();

	        try {
	            for (Files file : media) {
	                filesServiceImpl.deleteFile(file.getId());
	            }
	        } catch (Exception e) {
	            
	        }
	        
	        produitRepository.deleteById(id);
	    }
	
    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 public long gettime() {
    	
    	LocalDateTime localDateTime = LocalDateTime.now(); 
    	ZoneId tunisiaZone = ZoneId.of("Africa/Tunis");
    	ZonedDateTime zdtTunisia = ZonedDateTime.of(localDateTime, tunisiaZone);
    	long millis = zdtTunisia.toInstant().toEpochMilli();
		return millis;
		
	}
    
    

}
