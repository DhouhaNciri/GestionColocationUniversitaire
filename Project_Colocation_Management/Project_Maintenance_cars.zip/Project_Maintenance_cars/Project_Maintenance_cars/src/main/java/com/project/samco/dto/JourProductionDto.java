package com.project.samco.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;



import java.io.Serializable;



@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class JourProductionDto implements Serializable {
	private Long travallerId;
	private String travallerName;
	private Long posteId;
	private String posteOperation;
	private int Objectif;
	private int production;
    private float productivite;
    private float retouche;
    
}
