package com.project.samco.model;



import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class Produit  implements Serializable {
	


private static final long serialVersionUID = 1L;



@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


public Produit(@NonNull String name, @NonNull List<Files> media, String description) {
	super();
	this.name = name;
	this.media = media;
	this.description = description;
}

@NonNull
private  String name;



@ElementCollection
@OneToMany(cascade = CascadeType.ALL)
private  List<Files> media;

@ElementCollection
@OneToMany(cascade = CascadeType.ALL)
private List<Defaut> defauts;

private String description;








}
