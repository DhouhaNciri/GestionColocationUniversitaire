package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OneProduction implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @JsonIgnore
    @Temporal(TemporalType.DATE)
    private Date date;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "jour_production_id")
    private JourProduction jourProduction;

    @OneToOne
    private Travallier travallier;

    @OneToOne
    private Poste poste;
    
    /*@OneToMany(mappedBy = "oneProduction", cascade = CascadeType.ALL)
    private List<Heureproduction> heureproductions;
    */
    
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "one_production_id") 
    private List<Heureproduction> heureproductions;
    
    
    
    @OneToMany(mappedBy = "oneProduction", cascade = CascadeType.ALL)
    private List<JourDefaut> jourDefauts;


    
    
    private int objectif = 0;
    private int production;
    private float productivite;
    private float retouche;

   
    @PrePersist
    protected void onCreate() {
        if (this.date == null) {
            this.date = new Date();
        }
    }

    public OneProduction(Travallier travallier, Poste poste) {
        super();
        this.travallier = travallier;
        this.poste = poste;
    }
}
