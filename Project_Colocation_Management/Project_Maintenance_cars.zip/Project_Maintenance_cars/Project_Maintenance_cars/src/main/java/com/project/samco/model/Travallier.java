package com.project.samco.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import java.io.Serializable;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Travallier implements Serializable  {

    private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
@JsonIgnore
    @Column(length = 255)
    private String fingerprint;

    @NonNull
    private Long cin;

    @Column(length = 100)
    @NonNull
    private String name;

    @Column(length = 100)
    @NonNull
    private String prenome;

    @OneToOne
 //   @JsonIgnore
    private Poste defaultposte;

    @NonNull
   // @JsonIgnore
    private Date dateAjoute;

    public Travallier(String fingerprint, @NonNull Long cin, @NonNull String name, @NonNull String prenome, Poste defaultposte) {
        super();
        this.fingerprint = fingerprint;
        this.cin = cin;
        this.name = name;
        this.prenome = prenome;
        this.defaultposte = defaultposte;
    }
}
