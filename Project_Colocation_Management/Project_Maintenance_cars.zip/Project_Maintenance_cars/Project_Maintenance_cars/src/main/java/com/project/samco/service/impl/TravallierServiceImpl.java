package com.project.samco.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.project.samco.model.Poste;
import com.project.samco.model.Travallier;
import com.project.samco.repository.TravallierRepository;
import com.project.samco.service.TravallierService;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TravallierServiceImpl implements TravallierService {
	@Autowired
	PosteServiceImpl posteServiceImpl;

    private final TravallierRepository travallierRepository;

    public TravallierServiceImpl(TravallierRepository travallierRepository) {
        this.travallierRepository = travallierRepository;
    }

    @Override
    public Travallier saveTravallier(Travallier travallier) {
        try {
            travallier.setDateAjoute(new Date());
            return travallierRepository.save(travallier);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while saving Travallier", e);
        }
    }

    @Override
    public Travallier updateTravallier(Long id, Travallier updatedTravallier) {
        try {
            Optional<Travallier> existingTravallierOptional = travallierRepository.findById(id);
            if (existingTravallierOptional.isPresent()) {
                Travallier existingTravallier = existingTravallierOptional.get();
                existingTravallier.setFingerprint(updatedTravallier.getFingerprint());
                existingTravallier.setCin(updatedTravallier.getCin());
                existingTravallier.setName(updatedTravallier.getName());
                existingTravallier.setPrenome(updatedTravallier.getPrenome());
                existingTravallier.setDateAjoute(updatedTravallier.getDateAjoute());
                return travallierRepository.save(existingTravallier);
            } else {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Travallier not found");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while updating Travallier", e);
        }
    }

   
    public Travallier changedefaultPosteTravallier(Long travallierId, Long posteId) {
        try {
            Optional<Travallier> travallierOptional = travallierRepository.findById(travallierId);
            Poste poste = posteServiceImpl.getPosteById(posteId);
            if (travallierOptional.isPresent() && poste != null) {
                /*Travallier lastTravallier = travallierRepository.findByjourposte(poste);
                if (lastTravallier != null) {
                    lastTravallier.setJourposte(null);
                    travallierRepository.save(lastTravallier);
                }*/
                Travallier travallier = travallierOptional.get();
                travallier.setDefaultposte(poste);
                return travallierRepository.save(travallier);
            } else {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Travallier or Poste not found");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while changing Travallier's poste", e);
        }
    }

    @Override
    public List<Travallier> getAllTravalliers() {
        try {
            return travallierRepository.findAll();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving all Travalliers", e);
        }
    }

    @Override
    public Travallier getTravallierById(Long travallierId) {
        try {
            return travallierRepository.findById(travallierId).orElse(null);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by ID", e);
        }
    }
    
    
    public Boolean existeById(Long travallierId) {
        try {
            return travallierRepository.existsById(travallierId);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by ID", e);
        }
    }
    
    public Boolean existeByFingre(String travallierfinger) {
        try {
            return travallierRepository.existsByFingerprint(travallierfinger);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by ID", e);
        }
    }

 /*  @Override
    public Travallier getTravallierByposte(Poste poste) {
        try {
            return travallierRepository.findByjourposte(poste);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by Poste", e);
        }
    }*/

    @Override
    public Travallier getTravallierByFingerprint(String fingerprint) {
        try {
            return travallierRepository.findByFingerprint(fingerprint);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by fingerprint", e);
        }
    }

    @Override
    public Travallier getTravallierByCin(Long cin) {
        try {
            return travallierRepository.findBycin(cin);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while retrieving Travallier by cin", e);
        }
    }

    @Override
    public void deleteTravallier(Long id) {
        try {
            travallierRepository.deleteById(id);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while deleting Travallier", e);
        }
    }
}
