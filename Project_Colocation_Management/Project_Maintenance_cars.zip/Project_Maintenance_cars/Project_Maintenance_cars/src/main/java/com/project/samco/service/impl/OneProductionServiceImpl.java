package com.project.samco.service.impl;


import com.project.samco.model.Heureproduction;
import com.project.samco.model.Intervention;
import com.project.samco.model.JourDefaut;
import com.project.samco.model.OneProduction;
import com.project.samco.model.Poste;
import com.project.samco.model.Travallier;
import com.project.samco.repository.InterventionRepository;
import com.project.samco.repository.OneProductionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

@Service
public class OneProductionServiceImpl {
	
	
	
	
 @Autowired
    private  OneProductionRepository oneProductionRepository;
    @Autowired
    private  TravallierServiceImpl travallierServiceImpl;
    @Autowired
    private  PosteServiceImpl posteServiceImpl;
    @Autowired
    private  InterventionRepository interventionRepository;
    

   

    
  
    
    

    public OneProduction incrementProduction(Long id, int numbre) {
        try {
            OneProduction oneProduction = oneProductionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("oneProduction not found with id: " + id));
            List<Heureproduction> heureproductions = oneProduction.getHeureproductions();
            List<Intervention> interventions=interventionRepository.findByEtatAndPosteid("attente", oneProduction.getPoste().getId());
           interventions.addAll(interventionRepository.findByEtatAndPosteid("accepte", oneProduction.getPoste().getId()));
           Heureproduction heureproduction=new Heureproduction(oneProduction.getPoste().getId(), numbre, 0,( (float) numbre/(float) oneProduction.getPoste().getObjectif())*100);
           float piecetemp=60/oneProduction.getPoste().getObjectif();
        float tempreal=   (numbre*piecetemp/heureproduction.getMinutesAsInt())*100;
        heureproduction.setProductivite(tempreal);
    
          
            if (heureproductions.size()>0) {
            	
				if (heureproductions.get(heureproductions.size()-1).getHeuresAsInt()==heureproduction.getHeuresAsInt()&&heureproductions.get(heureproductions.size()-1).getPoste().equals(heureproduction.getPoste())) {
					heureproductions.get(heureproductions.size()-1).setProduction(heureproductions.get(heureproductions.size()-1).getProduction()+numbre);
					heureproductions.get(heureproductions.size()-1).setHeures(LocalDateTime.now());
					heureproductions.get(heureproductions.size()-1).setProductivite((heureproductions.get(heureproductions.size()-1).getProduction()*piecetemp)/(heureproductions.get(heureproductions.size()-1).getMinutesAsInt())*100);
					
					
					if (interventions!=null) {
						if (interventions.size()>0) {
							heureproductions.get(heureproductions.size()-1).setCommentaire("Casse Machine N°"+interventions.get(interventions.size()-1).getMachine());
						}	
						}
					
				}else {
					if (interventions!=null) {
						if (interventions.size()>0) {
							heureproduction.setCommentaire("Casse Machine N°"+interventions.get(interventions.size()-1).getMachine());
						}	
						}
					if (!heureproductions.get(heureproductions.size()-1).getPoste().equals(heureproduction.getPoste())) {
						 tempreal=   (numbre*piecetemp/(heureproduction.getMinutesAsInt()-heureproductions.get(heureproductions.size()-1).getMinutesAsInt())*100);
					        heureproduction.setProductivite(tempreal);
						
						
					
					}
					heureproductions.add(heureproduction);
					oneProduction.setObjectif(oneProduction.getObjectif()+oneProduction.getPoste().getObjectif());
					
				}
			}else {
				if (interventions!=null) {
					if (interventions.size()>0) {
						heureproduction.setCommentaire("Casse Machine N°"+interventions.get(interventions.size()-1).getMachine());
					}	
					}
				heureproductions.add(heureproduction);
				oneProduction.setObjectif(oneProduction.getObjectif()+oneProduction.getPoste().getObjectif());
			}
            
            oneProduction.setHeureproductions(heureproductions);
            
            
            oneProduction.setProduction(oneProduction.getProduction() + numbre);
            float some=0;
            for (Heureproduction heureproduction2 : heureproductions) {
            	
            	 some=some+heureproduction2.getProductivite();
				
			}
            
            
            
            
            oneProduction.setProductivite( (some/heureproductions.size()));
            Poste poste =oneProduction.getPoste();
          poste.setProductiontotal(poste.getProductiontotal() + numbre);
          poste.setProductivitetotal( (((float) poste.getProductiontotal() / (float) poste.getObjectif() )* 100));
            oneProduction.setPoste(poste);
           
            return oneProductionRepository.save(oneProduction);
        } catch (EntityNotFoundException e) {
           
            return null;
           
        }}

    
    
    public OneProduction incrementRetouche(Long id, int numbre) {
        try {
            OneProduction oneProduction = oneProductionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("OneProductin not found with id: " + id));
            List<Heureproduction> heureproductions = oneProduction.getHeureproductions();
            if (heureproductions.size()>0) {
				
			
            heureproductions.get(heureproductions.size()-1).setRetouche(heureproductions.get(heureproductions.size()-1).getRetouche()+numbre);}
            Poste poste =oneProduction.getPoste();
           // poste.setRetouchetotal(poste.getRetouchetotal() + numbre);
            oneProduction.setRetouche(oneProduction.getRetouche() + numbre);
            return oneProductionRepository.save(oneProduction);
        } catch (EntityNotFoundException e) {
            return null;
           
        }}
    
    
    
    
    
    
    

  
   public OneProduction changeTravallierJourPoste(Long posteId ,Long onproductionId) {
      //  Travallier travallier = travallierServiceImpl.getTravallierById(travallierId);
        Poste poste =posteServiceImpl.getPosteById(posteId);
        OneProduction oneProduction =oneProductionRepository.findById(onproductionId).orElseThrow();
        if (poste != null && oneProduction != null) {
        	//Travallier lasttravaller = travallierServiceImpl.getTravallierByposte(poste);
            /*if ( lasttravaller != null) {
            	
            	lasttravaller.setJourposte(null);
            	
            }*/
            
         /*   Poste lastpost = getPosteByTravaller(travallierId);
            if ( lastpost != null) {
            	 lastpost.setTravallier(null);
            	
            	
            }*/
          
        	oneProduction.setPoste(poste);
            return oneProductionRepository.save(oneProduction);
    } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Travallier or Poste not found");
        }
    }

   
    public OneProduction getOnProductionById(Long id) {
        Optional<OneProduction> optional = oneProductionRepository.findById(id);
        return optional.orElse(null);
    }
    
    
    public boolean existe(Travallier travallier, Date date) {
		return oneProductionRepository.existsByTravallierAndDate(travallier, date);
        
    }


    public OneProduction getOneProductioByTravaller(long travallierId,Date date) {
    	Travallier travallier = travallierServiceImpl.getTravallierById(travallierId);
    	if (travallier != null) {
    		return   oneProductionRepository.findByTravallierAndDate(travallier,date);
         }
		return null;
    }
  
    public OneProduction getOneProductionByPoste(long numeroposte, Date date) {
        Poste optionalPoste = posteServiceImpl.getPosteBynumeroposte(numeroposte);
        
        if (optionalPoste != null) {
            return oneProductionRepository.findByPosteAndDate(optionalPoste, date);
        } else {
            throw new NoSuchElementException("Poste not found for numeroposte: " + numeroposte);
        }
    }   
    
    
    
    
    
    
    public List<OneProduction> getAllOneProduction() {
        return oneProductionRepository.findAll();
    }

   
    public void deletOneProduction(Long id) {
    	oneProductionRepository.deleteById(id);
    }
    
    
    
    public OneProduction updateJourDefauts(Long oneProductionId, List<JourDefaut> updatedJourDefauts) {
        OneProduction oneProduction = oneProductionRepository.findById(oneProductionId)
                .orElseThrow(() -> new EntityNotFoundException("OneProduction not found with id: " + oneProductionId));
        oneProduction.setJourDefauts(updatedJourDefauts);
        return oneProductionRepository.save(oneProduction);
    }
    
    
    
    
}
