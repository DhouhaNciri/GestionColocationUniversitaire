package com.project.samco.service;

import com.project.samco.dto.DefautRepetation;
import com.project.samco.model.Defaut;
import com.project.samco.model.Files;

import java.util.List;
import java.util.Optional;

public interface DefautService {

    Defaut addDefaut(String name, List<Files> images) throws Exception;

    List<Defaut> getAllDefauts();

    Optional<Defaut> getDefautById(Long id);

    Defaut updateDefaut(Long id, String name, List<Files> images, int repetition, float percentage);

    DefautRepetation incrementDefaut(Long id, int repetition);

    void deleteDefautById(Long id) throws Exception;
}
