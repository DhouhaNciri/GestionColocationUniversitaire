// PosteService.java
package com.project.samco.service;

import com.project.samco.model.Poste;
import java.util.List;

public interface PosteService {

    Poste savePoste(Poste poste);

   Poste changeTravallier(Long travallierId, Long posteId);

    Poste getPosteById(Long id);

    Poste getPosteByNumeroPoste(String numeroPoste);

    List<Poste> getAllPostes();

    void deletePoste(Long id);
}
