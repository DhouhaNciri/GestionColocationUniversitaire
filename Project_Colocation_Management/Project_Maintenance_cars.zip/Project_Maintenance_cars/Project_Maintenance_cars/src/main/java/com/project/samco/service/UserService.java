package com.project.samco.service;

import com.project.samco.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User save(User newUser);
}
