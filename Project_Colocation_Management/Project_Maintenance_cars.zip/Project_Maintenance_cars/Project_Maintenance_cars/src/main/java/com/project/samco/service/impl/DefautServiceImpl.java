package com.project.samco.service.impl;

import com.project.samco.dto.DefautRepetation;
import com.project.samco.model.Defaut;
import com.project.samco.model.Files;
import com.project.samco.repository.DefautRepository;
import com.project.samco.service.DefautService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

@Service
public class DefautServiceImpl implements DefautService {

    @Autowired
    DefautRepository defautRepository;

    @Autowired
    FilesServiceImpl filesServiceImpl;

    @Override
    public Defaut addDefaut(String name, List<Files> list) throws Exception {
        return defautRepository.save(new Defaut(name, list));
    }

    @Override
    public List<Defaut> getAllDefauts() {
        return defautRepository.findAll();
    }

    @Override
    public Optional<Defaut> getDefautById(Long id) {
        return defautRepository.findById(id);
    }

    @Override
    public Defaut updateDefaut(Long id, String name, List<Files> images, int repetition, float percentage) {
        Optional<Defaut> existingDefautOptional = defautRepository.findById(id);
        if (existingDefautOptional.isPresent()) {
            Defaut existingDefaut = existingDefautOptional.get();
            existingDefaut.setName(name);
            existingDefaut.setImages(images);
            existingDefaut.setRepetition(repetition);
            existingDefaut.setPercentage(percentage);
            return defautRepository.save(existingDefaut);
        } else {
            return null;
        }
    }

    @Override
    public DefautRepetation incrementDefaut(Long id, int repetition) {
        try {
            Defaut existingDefaut = defautRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Defaut not found with id: " + id));

            Defaut.setTotalDefaut(Defaut.getTotalDefaut() + repetition);
            existingDefaut.setRepetition(existingDefaut.getRepetition() + repetition);
            existingDefaut.setPercentage((existingDefaut.getRepetition() / Defaut.getTotalDefaut() * 100));
            existingDefaut = defautRepository.save(existingDefaut);

            return new DefautRepetation(existingDefaut.getId(), existingDefaut.getName(), existingDefaut.getRepetition(), existingDefaut.getPercentage());
        } catch (EntityNotFoundException e) {
           
            return null;
           
        }}

    @Override
    public void deleteDefautById(Long id) throws Exception {
        List<Files> images = getDefautById(id).orElseThrow().getImages();

        try {
            for (Files file : images) {
                filesServiceImpl.deleteFile(file.getId());
            }
        } catch (Exception e) {
            
        }
        Defaut.setTotalDefaut(Defaut.getTotalDefaut()-defautRepository.getById(id).getRepetition());
        defautRepository.deleteById(id);
    }
}
