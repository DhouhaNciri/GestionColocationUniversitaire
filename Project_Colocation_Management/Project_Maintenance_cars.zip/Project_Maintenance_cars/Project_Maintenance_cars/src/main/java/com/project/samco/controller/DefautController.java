package com.project.samco.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.multipart.MultipartFile;
import com.project.samco.dto.DefautRepetation;
import com.project.samco.model.Defaut;
import com.project.samco.service.impl.DefautServiceImpl;
import com.project.samco.service.impl.FilesServiceImpl;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/defauts")
public class DefautController {

    @Autowired
    private DefautServiceImpl defautServiceImpl;
    @Autowired
    private FilesServiceImpl filesServiceImpl;

    @PostMapping
    public ResponseEntity<Defaut> addDefaut(@RequestParam String name, @RequestParam List<MultipartFile> files) throws Exception {
        if (!isAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Defaut newDefaut = defautServiceImpl.addDefaut(name, filesServiceImpl.storeFiles(files));
        return ResponseEntity.status(HttpStatus.CREATED).body(newDefaut);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDefautById(@PathVariable Long id) {
      
        if (!isAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        if (defautServiceImpl.getDefautById(id).isPresent()) {
            try {
                defautServiceImpl.deleteDefautById(id);
                return ResponseEntity.ok().body("Defaut with ID: " + id + " deleted successfully.");
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                     .body("Failed to delete defaut with ID: " + id);
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

  
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                             .anyMatch(role -> role.getAuthority().equals("ROLE_ADMIN"));
    }

    @GetMapping
    public ResponseEntity<List<Defaut>> getAllDefauts() {
        List<Defaut> defauts = defautServiceImpl.getAllDefauts();
        return ResponseEntity.ok(defauts);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Defaut> getDefautById(@PathVariable Long id) {
        Optional<Defaut> defaut = defautServiceImpl.getDefautById(id);
        return defaut.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Defaut> updateDefaut(@PathVariable Long id, @RequestBody Defaut defaut) {
        Defaut updatedDefaut = defautServiceImpl.updateDefaut(id, defaut.getName(), defaut.getImages(),
                                                        defaut.getRepetition(), defaut.getPercentage());
        if (updatedDefaut != null) {
            return ResponseEntity.ok(updatedDefaut);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/increment/{id}")
    public ResponseEntity<DefautRepetation> incrementDefaut(@PathVariable Long id, @RequestParam int repetition) {
        if (repetition < 1) {
            return ResponseEntity.badRequest().build();
        }

        DefautRepetation incrementedDefaut = defautServiceImpl.incrementDefaut(id, repetition);
        if (incrementedDefaut != null) {
            return ResponseEntity.ok(incrementedDefaut);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
