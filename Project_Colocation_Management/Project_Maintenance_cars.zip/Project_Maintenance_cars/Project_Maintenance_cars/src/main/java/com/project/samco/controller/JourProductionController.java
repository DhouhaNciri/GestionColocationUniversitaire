package com.project.samco.controller;

import com.project.samco.dto.JourProductionDto;
import com.project.samco.model.Heureproduction;
import com.project.samco.model.JourProduction;
import com.project.samco.model.OneProduction;
import com.project.samco.service.impl.DefautServiceImpl;
import com.project.samco.service.impl.JourProductionServiceImpl;
import com.project.samco.service.impl.TravallierServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/api/jourproduction")
public class JourProductionController {
	 @Autowired   
    private  JourProductionServiceImpl jourProductionService;
	 @Autowired   
	private TravallierServiceImpl travallierServiceImpl;
	 
	 @Autowired   
		private DefautServiceImpl defautServiceImpl;
		 
   
	 
	 @DeleteMapping()
	    public boolean delet() throws ParseException {
		jourProductionService.deletbydate();
		return true;
	    }
	 
	 @GetMapping("/date")
	 public ResponseEntity<List<JourProductionDto>> getJourProductionByDateString() {
	     try {
	         Optional<JourProduction> jourProduction = Optional.of(jourProductionService.JourProductionLancher());
	         if (jourProduction.isPresent()) {
	             List<JourProductionDto> jourProductionDtos = new ArrayList<>();
	             List<OneProduction> oneProductions = jourProduction.get().getPresence();
	             for (OneProduction oneProduction : oneProductions) {
	                 jourProductionDtos.add(new JourProductionDto(
	                         oneProduction.getTravallier().getId(),
	                         oneProduction.getTravallier().getName() + " " + oneProduction.getTravallier().getPrenome(),
	                         oneProduction.getPoste().getId(),
	                         oneProduction.getPoste().getOperation(),
	                         oneProduction.getObjectif(),
	                         oneProduction.getProduction(),
	                         oneProduction.getProductivite(),
	                         oneProduction.getRetouche()
	                 ));
	             }
	             return ResponseEntity.ok(jourProductionDtos);
	         } else {
	             return ResponseEntity.notFound().build();
	         }
	     } catch (ParseException e) {
	         return ResponseEntity.badRequest().build();
	     }
	 }

    
    @GetMapping("/distinctdates")
    public List<Date> getDistinctDates() {
        return jourProductionService.getDistinctDates();
    }
    
    
    @GetMapping("/date/{date}")
    public ResponseEntity<List<JourProductionDto>> getJourProductionByDateString(@PathVariable String date) {
        try {
            JourProduction jourProduction =jourProductionService.getJourProductionByDate(date).orElseThrow();
            if (jourProduction!=null) {
	             List<JourProductionDto> jourProductionDtos = new ArrayList<>();
	             List<OneProduction> oneProductions = jourProduction.getPresence();
	             for (OneProduction oneProduction : oneProductions) {
	                 jourProductionDtos.add(new JourProductionDto(
	                         oneProduction.getTravallier().getId(),
	                         oneProduction.getTravallier().getName() + " " + oneProduction.getTravallier().getPrenome(),
	                         oneProduction.getPoste().getId(),
	                         oneProduction.getPoste().getOperation(),
	                         oneProduction.getObjectif(),
	                         oneProduction.getProduction(),
	                         oneProduction.getProductivite(),
	                         oneProduction.getRetouche()
	                 ));
	             }
	             return ResponseEntity.ok(jourProductionDtos);
	         } else {
	             return ResponseEntity.notFound().build();
	         }
	     } catch (ParseException e) {
	         return ResponseEntity.badRequest().build();
	     }
               
           
    }
    
    
    
    
    @PutMapping("/presence/id/{idTravaller}")
    public String AddPresenceByid(@PathVariable Long idTravaller) {
        try {
          
           if (travallierServiceImpl.existeById(idTravaller)) {
        	  
              OneProduction oneProduction=  jourProductionService.updatePresence(travallierServiceImpl.getTravallierById(idTravaller));
              if (oneProduction!=null) {
  				
  			
                return oneProduction.getTravallier().getName()+" "+oneProduction.getTravallier().getPrenome()+" Poste "+oneProduction.getTravallier().getDefaultposte().getId();
              }else {
            	  return " Travaller present";
            	  
              }
           } else {
                return "Non Travaller";
            }
        } catch (ParseException e) {
            return "Non Travaller";
        }
    }
    
    
    @PutMapping("/presence/fing/{fingTravaller}")
    public ResponseEntity<OneProduction> AddPresenceByfing(@PathVariable String fingTravaller) {
        try {
          
           if (travallierServiceImpl.existeByFingre(fingTravaller)) {
                return ResponseEntity.ok(jourProductionService.updatePresence(travallierServiceImpl.getTravallierByFingerprint(fingTravaller)));
           } else {
                return ResponseEntity.notFound().build();
            }
        } catch (ParseException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/history")
    public ResponseEntity<?> getAllJourProduction() {
        try {
            List<JourProduction> jourProductions = jourProductionService.getAllJours();
            return new ResponseEntity<>(jourProductions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to retrieve Jours: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    
    @PutMapping("/incrementprod/poste/{nemeroposte}")
    public ResponseEntity<Object> incrementProduction(@PathVariable Long  nemeroposte,@RequestParam int augmentation) {
        try {
            OneProduction result = jourProductionService.incrementProductionbyposte(nemeroposte, augmentation);
            if (result != null) {
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NoSuchElementException e) {
           
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Poste not found for numeroposte: " + nemeroposte);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred");
        }
    }
    
    
    
    @PutMapping("/incrementprod/travaller/{id}")
    public ResponseEntity<Object> incrementProductionbuTravaller(@PathVariable Long  id,@RequestParam int augmentation) {
        try {
            OneProduction result = jourProductionService.incrementProductionbyTravaller(id, augmentation);
            if (result != null) {
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NoSuchElementException e) {
           
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Poste not found for id Travaller: " + id);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred");
        }
    }
    
    
    
    @GetMapping("/prodheurs/travaller/{id}/{date}")
    public ResponseEntity<Object> ProductionparTravaller(@PathVariable Long  id,@PathVariable String date) {
        try {
            List<Heureproduction> result = jourProductionService.ProductionHeurerbyTravaller(id,date);
            if (result != null) {
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NoSuchElementException e) {
           
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Poste not found for id Travaller: " + id);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred");
        }
    }
    
    
    
    
    
    
    @PutMapping("/incrementretouche/poste/{nemeroposte}")
    public ResponseEntity<Object> incrementRetouchByPoste(@PathVariable Long  nemeroposte,@RequestParam int augmentation) {
        try {
            OneProduction result = jourProductionService.incrementRetouchebyposte(nemeroposte, augmentation);
            if (result != null) {
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NoSuchElementException e) {
           
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Poste not found for numeroposte: " + nemeroposte);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred");
        }
    }
    
    @PutMapping("/{travallierId}/change-jour-poste/{posteId}")
    public OneProduction changeJourPosteTravallier(@PathVariable Long travallierId, @PathVariable Long posteId) {
        try {
        return	jourProductionService.ChangejourpostebyTravaller(travallierId, posteId);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while changing Travallier's poste", e);
        }
		
    }
    
    
    
    
    @PutMapping("/incrementretouche/travaller/{id}")
    public ResponseEntity<Object> incrementRetouchebyTravaller(@PathVariable Long  id,@RequestParam int augmentation) {
        try {
            OneProduction result = jourProductionService.incrementRetuchebyTravaller(id, augmentation);
            if (result != null) {
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NoSuchElementException e) {
           
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Poste not found for id Travaller: " + id);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred");
        }
    }
    
    
    
    
    
  
}
