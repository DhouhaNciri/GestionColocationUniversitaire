package com.project.samco.service.impl;

import com.project.samco.model.Defaut;
import com.project.samco.model.Heureproduction;
import com.project.samco.model.JourDefaut;
import com.project.samco.model.JourProduction;
import com.project.samco.model.OneProduction;
import com.project.samco.model.Travallier;
import com.project.samco.repository.JourDefautRepository;
import com.project.samco.repository.JourProductionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ArrayList;

@Service
public class JourProductionServiceImpl {
	@Autowired
    private  JourProductionRepository jourProductionRepository;
	@Autowired
    private  OneProductionServiceImpl oneProductionServiceImpl;
	
	@Autowired
	DefautServiceImpl defautServiceImpl;

	@Autowired
	JourDefautRepository defautRepository;


    

    public Optional<JourProduction> getJourProductionByDateString() throws ParseException {
    	  Date currentDate = new Date();
          SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
          String dateString = formatter.format(currentDate);
        Date date = formatter.parse(dateString);
        return jourProductionRepository.findByDate(date);
    }
    
    public Optional<JourProduction> getJourProductionByDate(String dateselect) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = formatter.parse(dateselect);
        return jourProductionRepository.findByDate(date);
    }

  
    public List<Date> getDistinctDates() {
        return jourProductionRepository.findDistinctDates();
    }
    
    

    public JourProduction saveJourProduction(JourProduction jourProduction) {
        return jourProductionRepository.save(jourProduction);
    }
    
    
    public void deletbydate() throws ParseException {
        jourProductionRepository.delete(JourProductionLancher());
    }
    
    
    public JourProduction JourProductionLancher() throws ParseException {
    	Date currentDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = formatter.format(currentDate);
      Date date = formatter.parse(dateString);
     if (!jourProductionRepository.existsByDate(date)) {
    	 return jourProductionRepository.save(new JourProduction());
		
	}
	return getJourProductionByDateString().orElseThrow(); 
    	
  
       
    }
    
    
    
    
    
    
    public OneProduction updatePresence(Travallier travallier) throws ParseException {
        JourProduction jourProduction = JourProductionLancher();
        
        if (jourProduction.getPresence() == null) {
            jourProduction.setPresence(new ArrayList<>());
        }
        if (oneProductionServiceImpl.existe(travallier, jourProduction.getDate())) {
        	return null;

		}else {
			
		 OneProduction oneProduction=new OneProduction(travallier, travallier.getDefaultposte());
		// oneProduction.setObjectif(travallier.getDefaultposte().getObjectif());
		 jourProduction.getPresence().add(oneProduction);
          jourProductionRepository.save(jourProduction);
          return oneProduction;
		
		
		}
        
           
        
    }
    
    public List<JourProduction> getAllJours() {
        return jourProductionRepository.findAll();
    }
    
    
    
    
    public OneProduction incrementProductionbyposte(Long numeroposte, int numbre) {
        try {
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductionByPoste(numeroposte, getDate());
         

            if (oneProduction!=null) {
               
                long idOneProduction = oneProduction.getId();
                return oneProductionServiceImpl.incrementProduction(idOneProduction, numbre);
            } else {
               
                System.out.println("OneProduction entity not found for post number: " + numeroposte);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    
    public OneProduction incrementProductionbyTravaller(Long idtravaller, int numbre) {
        try {
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductioByTravaller(idtravaller, getDate());
         

            if (oneProduction!=null) {
               
                long idOneProduction = oneProduction.getId();
                return oneProductionServiceImpl.incrementProduction(idOneProduction, numbre);
            } else {
               
                System.out.println("OneProduction entity not found for Travaller id: " + idtravaller);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    public List<Heureproduction> ProductionHeurerbyTravaller(Long idtravaller,String dateselect) {
        try {
        	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date date = formatter.parse(dateselect);
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductioByTravaller(idtravaller, date);
         

            if (oneProduction!=null) {
               
                
                return oneProduction.getHeureproductions();
            } else {
               
                System.out.println("OneProduction entity not found for Travaller id: " + idtravaller);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    
    
    
    
    public OneProduction incrementRetuchebyTravaller(Long idtravaller, int numbre) {
        try {
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductioByTravaller(idtravaller, getDate());
         

            if (oneProduction!=null) {
               
                long idOneProduction = oneProduction.getId();
                return oneProductionServiceImpl.incrementRetouche(idOneProduction, numbre);
            } else {
               
                System.out.println("OneProduction entity not found for Travaller id: " + idtravaller);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    public OneProduction ChangejourpostebyTravaller(Long idtravaller, Long idposte) {
        try {
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductioByTravaller(idtravaller, getDate());
         

            if (oneProduction!=null) {
               
                long idOneProduction = oneProduction.getId();
                return oneProductionServiceImpl.changeTravallierJourPoste(idposte, idOneProduction);
            } else {
               
                System.out.println("OneProduction entity not found for Travaller id: " + idtravaller);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    public OneProduction incrementRetouchebyposte(Long numeroposte, int numbre) {
        try {
        	OneProduction oneProduction=oneProductionServiceImpl.getOneProductionByPoste(numeroposte, getDate());
         

            if (oneProduction!=null) {
               
                long idOneProduction = oneProduction.getId();
                return oneProductionServiceImpl.incrementRetouche(idOneProduction, numbre);
            } else {
               
                System.out.println("OneProduction entity not found for post number: " + numeroposte);
                return null;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    
    
    
    
    
    public JourProduction updateJourDefaut(Travallier travallier,Defaut defaut,int repetation) throws ParseException {
        JourProduction jourProduction = JourProductionLancher();
        
        if (jourProduction.getPresence() == null) {
            jourProduction.setPresence(new ArrayList<>());
        }
        if (oneProductionServiceImpl.existe(travallier, jourProduction.getDate())) {
        
       OneProduction oneProduction= oneProductionServiceImpl.getOneProductioByTravaller(travallier.getId(), jourProduction.getDate());
       oneProductionServiceImpl.incrementRetouche(oneProduction.getId(),(int)oneProduction.getRetouche()+ repetation);
       if (defautRepository.existsByDefautAndDateAndOneProduction(defaut,jourProduction.getDate(), oneProduction)) {
    	JourDefaut jourDefaut=   defautRepository.findByDefautAndDateAndOneProduction( defaut, jourProduction.getDate(), oneProduction);
    	jourDefaut.setRepetitionjour(jourDefaut.getRepetitionjour()+repetation);
    		defautRepository.save(jourDefaut);
	}else {
		
		
		 List<JourDefaut>   JourDefauts=oneProduction.getJourDefauts();
		    JourDefauts.add(new JourDefaut(defaut, oneProduction, repetation));
		      oneProductionServiceImpl.updateJourDefauts(oneProduction.getId(), JourDefauts);	
	}
       
       
       
       
		}else {
			
		 OneProduction oneProduction=new OneProduction(travallier, travallier.getDefaultposte());
		 oneProduction.setObjectif(travallier.getDefaultposte().getObjectif());
		 jourProduction.getPresence().add(oneProduction);
         return jourProductionRepository.save(jourProduction);
		
		
		}
       defautServiceImpl.incrementDefaut(defaut.getId(), repetation);
       
		return jourProduction;
		}
    public Date getDate() throws ParseException {
     Date currentDate = new Date();
     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
     String dateString = formatter.format(currentDate);
     Date date = formatter.parse(dateString);
	return date;
    }
    
    
}
