package com.project.samco.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import com.project.samco.model.Intervention;
@Repository
public interface InterventionRepository extends JpaRepository<Intervention, Long> {
	List<Intervention> findByDemenderId(Long id);
	List<Intervention> findByRealisesId(Long id);
	List<Intervention> findByRealisesIdAndEtat(Long realisesId, String etat);
	List<Intervention> findByEtat(String etat);
	List<Intervention> findByEtatAndPosteid(String etat,Long posteid);
}
