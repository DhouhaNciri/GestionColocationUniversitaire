// AuthenticationServiceImpl.java
package com.project.samco.service.impl;

import com.project.samco.dto.JwtAuthenticationResponse;
import com.project.samco.dto.SignInRequest;
import com.project.samco.dto.SignUpRequest;
import com.project.samco.model.Role;
import com.project.samco.model.User;
import com.project.samco.repository.UserRepository;
import com.project.samco.service.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtServiceImpl jwtServiceImpl;
    private final AuthenticationManager authenticationManager;

    @Override
    public JwtAuthenticationResponse signup(SignUpRequest request) {
        if (!userRepository.existsByEmail(request.getEmail())) {
            try {
            	Role role;
            	if (request.getRole().equals("admin")) {
            		role=Role.ROLE_ADMIN;
				}else {
					if (request.getRole().equals("technicien")) {
	            		role=Role.ROLE_TECHNICIEN;
					}else {
						if (request.getRole().equals("qulite")) {
							role=Role.ROLE_CONTROLE_QULITE;
						}else {
							
							if (request.getRole().equals("production")) {
								role=Role.ROLE_CONTROLE_PROD;
							}else {
						
					
					role=Role.ROLE_USER;}}}
				}
                User user = User.builder()
                        .firstName(request.getFirstName())
                        .lastName(request.getLastName())
                        .email(request.getEmail())
                        .password(passwordEncoder.encode(request.getPassword()))
                        .role(role)
                        .build();

                user = userRepository.save(user);

                String token = jwtServiceImpl.generateToken(user);

                return JwtAuthenticationResponse.builder().token(token).role(user.getRole().toString()).build();
            } catch (Exception e) {
              
                throw new RuntimeException("Error occurred during signup.", e);
            }
        } else {
            throw new RuntimeException("User with email already exists.");
        }
    }

    @Override
    public JwtAuthenticationResponse signin(SignInRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

            User user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new IllegalArgumentException("Invalid email or password."));

            String token = jwtServiceImpl.generateToken(user);

            return JwtAuthenticationResponse.builder().token(token).role(user.getRole().toString()).build();
        } catch (Exception e) {
         
            throw new RuntimeException("Error occurred during signin.", e);
        }
    }
    
    
}
