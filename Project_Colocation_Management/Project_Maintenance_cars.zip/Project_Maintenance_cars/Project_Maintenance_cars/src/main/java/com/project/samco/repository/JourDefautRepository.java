package com.project.samco.repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.project.samco.model.Defaut;
import com.project.samco.model.JourDefaut;
import com.project.samco.model.OneProduction;

@Repository
public interface JourDefautRepository extends JpaRepository<JourDefaut, Long> {
	JourDefaut findByDefautAndDateAndOneProduction(Defaut defaut, Date date,OneProduction oneProduction);
	//JourDefaut findByPosteAndDate(Poste poste, Date date);
    List<JourDefaut> findAllByDate(Date date);
    boolean existsByDefautAndDateAndOneProduction(Defaut defaut, Date date,OneProduction oneproduction);
}
