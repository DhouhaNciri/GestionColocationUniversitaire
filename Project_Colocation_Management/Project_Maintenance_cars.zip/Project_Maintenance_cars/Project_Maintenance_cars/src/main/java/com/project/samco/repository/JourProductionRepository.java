package com.project.samco.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.project.samco.model.JourProduction;

@Repository
public interface JourProductionRepository extends JpaRepository<JourProduction, Long> {
    Optional<JourProduction> findByDate(Date date);
    boolean existsByDate(Date date);
    @Query("SELECT DISTINCT jp.date FROM JourProduction jp ORDER BY jp.date DESC")
    List<Date> findDistinctDates();

}
