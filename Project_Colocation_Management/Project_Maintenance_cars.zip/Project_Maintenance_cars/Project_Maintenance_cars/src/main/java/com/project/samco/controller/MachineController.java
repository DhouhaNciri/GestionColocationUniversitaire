package com.project.samco.controller;

import com.project.samco.model.Machine;
import com.project.samco.model.Poste;
import com.project.samco.service.impl.MachineServiceImpl;
import com.project.samco.service.impl.PosteServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/machines")
public class MachineController {

    @Autowired
    private MachineServiceImpl machineService;
    @Autowired
    private PosteServiceImpl posteServiceImpl;
    @PutMapping("/{id}/update-poste")
    public ResponseEntity<Machine> updateMachinePoste(@PathVariable Long id, @RequestParam Long newPosteId) {
    
        Optional<Machine> optionalMachine = machineService.getMachineById(id);
        if (optionalMachine.isPresent()) {
            Machine existingMachine = optionalMachine.get();
       
            Poste optionalPoste = posteServiceImpl.getPosteById(newPosteId);
            if (optionalPoste!=null) {
                existingMachine.setPoste(optionalPoste);
                Machine updatedMachine = machineService.saveMachine(existingMachine);
                return ResponseEntity.ok(updatedMachine);
            } else {
              
                return ResponseEntity.badRequest().body(null);
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @GetMapping
    public ResponseEntity<List<Machine>> getAllMachines() {
        List<Machine> machines = machineService.getAllMachines();
        return ResponseEntity.ok(machines);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Machine> getMachineById(@PathVariable Long id) {
        Optional<Machine> machine = machineService.getMachineById(id);
        return machine.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Machine> saveMachine(@RequestBody Machine machine) {
        Machine savedMachine = machineService.saveMachine(machine);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedMachine);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Machine> updateMachine(@PathVariable Long id, @RequestBody Machine machine) {
        Machine updatedMachine = machineService.updateMachine(id, machine);
        return ResponseEntity.ok(updatedMachine);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMachine(@PathVariable Long id) {
        machineService.deleteMachine(id);
        return ResponseEntity.noContent().build();
    }
}
